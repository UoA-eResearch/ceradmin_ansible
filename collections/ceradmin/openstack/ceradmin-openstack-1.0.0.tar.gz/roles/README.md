# Ansible Collection - ceradmin.openstack

Documentation for the collection.
